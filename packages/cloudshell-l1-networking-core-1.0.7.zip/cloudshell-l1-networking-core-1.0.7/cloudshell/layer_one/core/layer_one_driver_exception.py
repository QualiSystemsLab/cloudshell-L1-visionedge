#!/usr/bin/python
# -*- coding: utf-8 -*-


class LayerOneDriverException(Exception):
    """
    Basic L1 exception
    """
    pass
